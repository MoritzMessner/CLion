//
// Created by moritz on 18.05.2021.
//

#ifndef CLION_AUFGABE9_H
#define CLION_AUFGABE9_H


class Aufgabe9 {

};


#endif //CLION_AUFGABE9_H
