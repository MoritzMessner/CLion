//
// Created by moritz on 11.05.2021.
//

#ifndef CLION_AUFGABE8_H
#define CLION_AUFGABE8_H


class Aufgabe8 {

};


#endif //CLION_AUFGABE8_H
