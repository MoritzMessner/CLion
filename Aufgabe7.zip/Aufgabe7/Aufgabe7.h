//
// Created by moritz on 04.05.2021.
//

#ifndef CLION_AUFGABE7_H
#define CLION_AUFGABE7_H


class Aufgabe7 {

};


#endif //CLION_AUFGABE7_H
